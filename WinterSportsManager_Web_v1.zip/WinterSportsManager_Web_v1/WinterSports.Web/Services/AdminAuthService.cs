using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;
using WinterSports.Web.Models;

namespace WinterSports.Web.Services;

public class AdminAuthService
{
    private readonly AppDbContext _db;
    private readonly PasswordHasher<AdminUser> _hasher = new();

    public AdminAuthService(AppDbContext db)
    {
        _db = db;
    }

    public async Task<AdminUser?> ValidateAsync(string email, string password)
    {
        var user = await _db.AdminUsers.FirstOrDefaultAsync(x => x.Email == email);

        if (user == null)
        {
            return null;
        }

        var result = _hasher.VerifyHashedPassword(user, user.PasswordHash, password);

        if (result == PasswordVerificationResult.Failed)
        {
            return null;
        }

        return user;
    }
}
