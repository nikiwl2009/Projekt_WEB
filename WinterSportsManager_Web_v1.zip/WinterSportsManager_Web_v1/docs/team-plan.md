# Podział pracy na 4 osoby

| Osoba | Obszar | Konkretne zadania | Pliki/katalogi | Priorytet | Zależności |
|---|---|---|---|---|---|
| Osoba 1 | Backend i baza | modele, DbContext, seed, walidacja, relacje, CRUD | `Models`, `Data`, `Areas/Admin/Controllers` | Wysoki | blokuje frontend admina |
| Osoba 2 | Frontend i UX | layout, CSS, responsywność, animacje, karty, tabele | `Views`, `wwwroot/css`, `wwwroot/js` | Wysoki | potrzebuje modeli i tras |
| Osoba 3 | Logowanie i panel admina | cookie auth/Identity, zabezpieczenie panelu, dashboard, toasty | `AccountController`, `Areas/Admin`, `Services` | Wysoki | zależy od backendu |
| Osoba 4 | Wykresy i dokumentacja | Chart.js, README, instrukcja, QA, walidacja W3C | `Views/Home`, `docs`, `README.md` | Średni/Wysoki | zależy od danych |

## Plan commitów

1. `init: create ASP.NET Core MVC web application`
2. `feat: add domain models and database context`
3. `feat: add public pages and athlete listing`
4. `feat: add admin CRUD`
5. `feat: add cookie login and admin protection`
6. `feat: add admin dashboard`
7. `feat: add charts and CSV export`
8. `style: add winter dashboard UI and animations`
9. `docs: add README and documentation`
10. `chore: final QA and cleanup`
