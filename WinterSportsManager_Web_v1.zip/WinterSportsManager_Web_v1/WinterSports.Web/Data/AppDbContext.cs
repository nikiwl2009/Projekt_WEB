using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Models;

namespace WinterSports.Web.Data;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
    {
    }

    public DbSet<Athlete> Athletes => Set<Athlete>();
    public DbSet<Discipline> Disciplines => Set<Discipline>();
    public DbSet<CompetitionEvent> CompetitionEvents => Set<CompetitionEvent>();
    public DbSet<Result> Results => Set<Result>();
    public DbSet<PageContent> PageContents => Set<PageContent>();
    public DbSet<AdminUser> AdminUsers => Set<AdminUser>();

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<Discipline>()
            .HasIndex(x => x.Name)
            .IsUnique();

        modelBuilder.Entity<PageContent>()
            .HasIndex(x => x.Key)
            .IsUnique();

        modelBuilder.Entity<Athlete>()
            .HasOne(x => x.Discipline)
            .WithMany(x => x.Athletes)
            .HasForeignKey(x => x.DisciplineId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<CompetitionEvent>()
            .HasOne(x => x.Discipline)
            .WithMany(x => x.Events)
            .HasForeignKey(x => x.DisciplineId)
            .OnDelete(DeleteBehavior.Restrict);

        modelBuilder.Entity<Result>()
            .HasOne(x => x.Athlete)
            .WithMany(x => x.Results)
            .HasForeignKey(x => x.AthleteId)
            .OnDelete(DeleteBehavior.Cascade);

        modelBuilder.Entity<Result>()
            .HasOne(x => x.CompetitionEvent)
            .WithMany(x => x.Results)
            .HasForeignKey(x => x.CompetitionEventId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
