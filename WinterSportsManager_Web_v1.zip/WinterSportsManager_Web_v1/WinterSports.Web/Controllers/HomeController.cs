using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;
using WinterSports.Web.Models.ViewModels;

namespace WinterSports.Web.Controllers;

public class HomeController : Controller
{
    private readonly AppDbContext _db;

    public HomeController(AppDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        var vm = new DashboardViewModel
        {
            AthletesCount = await _db.Athletes.CountAsync(),
            DisciplinesCount = await _db.Disciplines.CountAsync(),
            EventsCount = await _db.CompetitionEvents.CountAsync(),
            ResultsCount = await _db.Results.CountAsync(),
            AthletesByDiscipline = await _db.Disciplines
                .Select(x => new KeyValuePair<string, int>(x.Name, x.Athletes.Count))
                .ToListAsync(),
            TopAthletes = await _db.Athletes
                .OrderByDescending(x => x.Points)
                .Take(5)
                .Select(x => new KeyValuePair<string, int>(x.FirstName + " " + x.LastName, x.Points))
                .ToListAsync(),
            LatestResults = await _db.Results
                .Include(x => x.Athlete)
                .Include(x => x.CompetitionEvent)
                .OrderByDescending(x => x.Date)
                .Take(5)
                .ToListAsync()
        };

        ViewBag.Hero = await _db.PageContents.FirstOrDefaultAsync(x => x.Key == "home.hero");

        return View(vm);
    }

    public IActionResult StatusCode(int code)
    {
        ViewBag.Code = code;
        return View();
    }
}
