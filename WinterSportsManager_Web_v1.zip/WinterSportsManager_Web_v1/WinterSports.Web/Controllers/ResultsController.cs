using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;

namespace WinterSports.Web.Controllers;

public class ResultsController : Controller
{
    private readonly AppDbContext _db;

    public ResultsController(AppDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        var results = await _db.Results
            .Include(x => x.Athlete)
            .Include(x => x.CompetitionEvent)
            .ThenInclude(x => x!.Discipline)
            .OrderByDescending(x => x.Date)
            .ToListAsync();

        return View(results);
    }
}
