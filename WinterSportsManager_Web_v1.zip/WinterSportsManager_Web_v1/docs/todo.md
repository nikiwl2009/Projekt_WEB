# Lista dalszych zadań

| Kategoria | Zadanie | Priorytet | Osoba | Blokuje |
|---|---|---|---|---|
| Krytyczne | Uruchomić projekt na 4 komputerach zespołu | Wysoki | Wszyscy | final QA |
| Krytyczne | Sprawdzić dodawanie, edycję i usuwanie zawodników | Wysoki | Osoba 1 | oddanie |
| Krytyczne | Zweryfikować logowanie admina | Wysoki | Osoba 3 | panel |
| Wymagane | Dodać CRUD zawodów | Średni | Osoba 1 | pełniejsze wyniki |
| Wymagane | Sprawdzić responsywność mobile | Wysoki | Osoba 2 | ocena frontend |
| Efekt wow | Dopracować wykres wyników w czasie | Średni | Osoba 4 | nie |
| Efekt wow | Dodać skeleton loader albo animowane statystyki | Niski | Osoba 2 | nie |
| Dokumentacja | Uzupełnić screeny w instrukcji | Średni | Osoba 4 | dokumentacja |
| Testowanie | W3C validator dla publicznych widoków | Średni | Osoba 4 | final QA |
| Kosmetyka | Favicon i lepsze zdjęcia zimowe | Niski | Osoba 2 | nie |
