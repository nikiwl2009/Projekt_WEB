using System.Text;
using WinterSports.Web.Models;

namespace WinterSports.Web.Services;

public class FileExportService
{
    public byte[] AthletesToCsv(IEnumerable<Athlete> athletes)
    {
        var sb = new StringBuilder();
        sb.AppendLine("Imie,Nazwisko,Wiek,Kraj,Klub,Dyscyplina,Punkty,Status");

        foreach (var athlete in athletes)
        {
            sb.AppendLine($"{Escape(athlete.FirstName)},{Escape(athlete.LastName)},{athlete.Age},{Escape(athlete.Country)},{Escape(athlete.ClubName)},{Escape(athlete.Discipline?.Name)},{athlete.Points},{athlete.Status}");
        }

        return Encoding.UTF8.GetBytes(sb.ToString());
    }

    private static string Escape(string? value)
    {
        value ??= string.Empty;
        value = value.Replace("\"", "\"\"");

        if (value.Contains(',') || value.Contains('"') || value.Contains('\n'))
        {
            return $"\"{value}\"";
        }

        return value;
    }
}
