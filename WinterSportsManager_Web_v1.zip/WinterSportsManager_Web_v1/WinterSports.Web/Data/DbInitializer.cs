using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Models;

namespace WinterSports.Web.Data;

public static class DbInitializer
{
    public static void Seed(AppDbContext db, IConfiguration configuration)
    {
        if (!db.Disciplines.Any())
        {
            var narciarstwo = new Discipline
            {
                Name = "Narciarstwo alpejskie",
                Description = "Konkurencje szybkościowe i techniczne, slalom, gigant, supergigant.",
                AccentColor = "#38bdf8"
            };

            var snowboard = new Discipline
            {
                Name = "Snowboard",
                Description = "Dyscyplina zimowa łącząca technikę, szybkość i styl.",
                AccentColor = "#f97316"
            };

            var biegi = new Discipline
            {
                Name = "Biegi narciarskie",
                Description = "Wytrzymałość, tempo i regularność na trasach zimowych.",
                AccentColor = "#22c55e"
            };

            db.Disciplines.AddRange(narciarstwo, snowboard, biegi);
            db.SaveChanges();

            db.Athletes.AddRange(
                new Athlete { FirstName = "Kamil", LastName = "Wójcik", Age = 24, Country = "Polska", ClubName = "AZS Snow Team", Points = 820, DisciplineId = narciarstwo.Id, Status = AthleteStatus.Aktywny, Bio = "Specjalista od slalomu i giganta." },
                new Athlete { FirstName = "Maja", LastName = "Nowak", Age = 21, Country = "Polska", ClubName = "Ice Riders", Points = 760, DisciplineId = snowboard.Id, Status = AthleteStatus.Aktywny, Bio = "Mocna w konkurencjach freestyle." },
                new Athlete { FirstName = "Adam", LastName = "Kowalski", Age = 29, Country = "Polska", ClubName = "Nordic Club", Points = 690, DisciplineId = biegi.Id, Status = AthleteStatus.Kontuzjowany, Bio = "Doświadczony zawodnik biegowy." }
            );

            db.CompetitionEvents.AddRange(
                new CompetitionEvent { Name = "Puchar Tatr", Location = "Zakopane", Date = DateTime.Today.AddDays(-30), DisciplineId = narciarstwo.Id, Difficulty = 7, BasePoints = 120 },
                new CompetitionEvent { Name = "Winter Freestyle Cup", Location = "Białka Tatrzańska", Date = DateTime.Today.AddDays(-18), DisciplineId = snowboard.Id, Difficulty = 8, BasePoints = 140 },
                new CompetitionEvent { Name = "Nordic Challenge", Location = "Szklarska Poręba", Date = DateTime.Today.AddDays(-9), DisciplineId = biegi.Id, Difficulty = 6, BasePoints = 100 }
            );

            db.PageContents.AddRange(
                new PageContent { Key = "home.hero", Title = "System zarządzania zawodnikami sportów zimowych", Body = "Nowoczesna aplikacja webowa do prowadzenia listy zawodników, dyscyplin, zawodów i wyników." },
                new PageContent { Key = "about.project", Title = "O projekcie", Body = "Projekt powstał jako webowa kontynuacja wcześniejszej aplikacji WPF. Zachowuje temat sportów zimowych, ale dodaje panel admina, wykresy i responsywny interfejs." }
            );

            db.SaveChanges();

            var athletes = db.Athletes.ToList();
            var events = db.CompetitionEvents.ToList();

            db.Results.AddRange(
                new Result { AthleteId = athletes[0].Id, CompetitionEventId = events[0].Id, Place = 1, Points = 120, Date = events[0].Date, Note = "Najlepszy przejazd dnia." },
                new Result { AthleteId = athletes[1].Id, CompetitionEventId = events[1].Id, Place = 2, Points = 110, Date = events[1].Date, Note = "Bardzo wysoka nota za styl." },
                new Result { AthleteId = athletes[2].Id, CompetitionEventId = events[2].Id, Place = 4, Points = 80, Date = events[2].Date, Note = "Dobry wynik po przerwie." }
            );

            db.SaveChanges();
        }

        if (!db.AdminUsers.Any())
        {
            var email = configuration["AdminAccount:Email"] ?? "admin@example.com";
            var password = configuration["AdminAccount:Password"] ?? "Admin123!";

            var admin = new AdminUser { Email = email };
            var hasher = new PasswordHasher<AdminUser>();
            admin.PasswordHash = hasher.HashPassword(admin, password);

            db.AdminUsers.Add(admin);
            db.SaveChanges();
        }
    }
}
