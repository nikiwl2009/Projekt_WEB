using System.ComponentModel.DataAnnotations;

namespace WinterSports.Web.Models;

public class Athlete
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Podaj imię.")]
    [StringLength(40, MinimumLength = 2)]
    [Display(Name = "Imię")]
    public string FirstName { get; set; } = string.Empty;

    [Required(ErrorMessage = "Podaj nazwisko.")]
    [StringLength(60, MinimumLength = 2)]
    [Display(Name = "Nazwisko")]
    public string LastName { get; set; } = string.Empty;

    [Range(6, 70, ErrorMessage = "Wiek musi być w zakresie 6–70.")]
    [Display(Name = "Wiek")]
    public int Age { get; set; }

    [Display(Name = "Kraj")]
    [StringLength(60)]
    public string Country { get; set; } = "Polska";

    [Display(Name = "Klub")]
    [StringLength(80)]
    public string? ClubName { get; set; }

    [Range(0, 100000)]
    [Display(Name = "Punkty")]
    public int Points { get; set; }

    [Display(Name = "Status")]
    public AthleteStatus Status { get; set; } = AthleteStatus.Aktywny;

    [Display(Name = "Zdjęcie")]
    public string? PhotoPath { get; set; }

    [Display(Name = "Opis")]
    [StringLength(1000)]
    public string? Bio { get; set; }

    [Required]
    [Display(Name = "Dyscyplina")]
    public int DisciplineId { get; set; }

    public Discipline? Discipline { get; set; }

    public List<Result> Results { get; set; } = new();

    public string FullName => $"{FirstName} {LastName}";
}
