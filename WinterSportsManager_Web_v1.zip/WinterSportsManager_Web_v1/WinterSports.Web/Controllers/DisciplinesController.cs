using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;

namespace WinterSports.Web.Controllers;

public class DisciplinesController : Controller
{
    private readonly AppDbContext _db;

    public DisciplinesController(AppDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        var disciplines = await _db.Disciplines
            .Include(x => x.Athletes)
            .OrderBy(x => x.Name)
            .ToListAsync();

        return View(disciplines);
    }
}
