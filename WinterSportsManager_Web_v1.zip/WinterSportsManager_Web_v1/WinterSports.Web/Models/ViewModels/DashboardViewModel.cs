namespace WinterSports.Web.Models.ViewModels;

public class DashboardViewModel
{
    public int AthletesCount { get; set; }
    public int DisciplinesCount { get; set; }
    public int EventsCount { get; set; }
    public int ResultsCount { get; set; }
    public List<KeyValuePair<string, int>> AthletesByDiscipline { get; set; } = new();
    public List<KeyValuePair<string, int>> TopAthletes { get; set; } = new();
    public List<Result> LatestResults { get; set; } = new();
}
