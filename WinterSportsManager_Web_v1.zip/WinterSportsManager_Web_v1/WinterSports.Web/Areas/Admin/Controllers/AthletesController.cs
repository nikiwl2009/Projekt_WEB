using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;
using WinterSports.Web.Models;

namespace WinterSports.Web.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize]
public class AthletesController : Controller
{
    private readonly AppDbContext _db;
    private readonly IWebHostEnvironment _env;

    public AthletesController(AppDbContext db, IWebHostEnvironment env)
    {
        _db = db;
        _env = env;
    }

    public async Task<IActionResult> Index()
    {
        var athletes = await _db.Athletes.Include(x => x.Discipline).OrderByDescending(x => x.Points).ToListAsync();
        return View(athletes);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        await FillLists();
        return View("CreateEdit", new Athlete());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Athlete athlete, IFormFile? photo)
    {
        if (!ModelState.IsValid)
        {
            await FillLists();
            return View("CreateEdit", athlete);
        }

        athlete.PhotoPath = await SavePhoto(photo);
        _db.Athletes.Add(athlete);
        await _db.SaveChangesAsync();

        TempData["Toast"] = "Dodano zawodnika.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var athlete = await _db.Athletes.FindAsync(id);

        if (athlete == null)
        {
            return NotFound();
        }

        await FillLists();
        return View("CreateEdit", athlete);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(Athlete athlete, IFormFile? photo)
    {
        if (!ModelState.IsValid)
        {
            await FillLists();
            return View("CreateEdit", athlete);
        }

        var existing = await _db.Athletes.AsNoTracking().FirstOrDefaultAsync(x => x.Id == athlete.Id);

        if (existing == null)
        {
            return NotFound();
        }

        var newPhoto = await SavePhoto(photo);
        athlete.PhotoPath = newPhoto ?? existing.PhotoPath;

        _db.Athletes.Update(athlete);
        await _db.SaveChangesAsync();

        TempData["Toast"] = "Zapisano zmiany zawodnika.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Delete(int id)
    {
        var athlete = await _db.Athletes.Include(x => x.Discipline).FirstOrDefaultAsync(x => x.Id == id);

        if (athlete == null)
        {
            return NotFound();
        }

        return View(athlete);
    }

    [HttpPost, ActionName("Delete")]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> DeleteConfirmed(int id)
    {
        var athlete = await _db.Athletes.FindAsync(id);

        if (athlete != null)
        {
            _db.Athletes.Remove(athlete);
            await _db.SaveChangesAsync();
            TempData["Toast"] = "Usunięto zawodnika.";
        }

        return RedirectToAction(nameof(Index));
    }

    private async Task FillLists()
    {
        ViewBag.Disciplines = new SelectList(await _db.Disciplines.OrderBy(x => x.Name).ToListAsync(), "Id", "Name");
    }

    private async Task<string?> SavePhoto(IFormFile? file)
    {
        if (file == null || file.Length == 0)
        {
            return null;
        }

        var allowed = new[] { ".jpg", ".jpeg", ".png", ".webp" };
        var ext = Path.GetExtension(file.FileName).ToLowerInvariant();

        if (!allowed.Contains(ext))
        {
            return null;
        }

        var folder = Path.Combine(_env.WebRootPath, "uploads", "athletes");
        Directory.CreateDirectory(folder);

        var fileName = $"{Guid.NewGuid()}{ext}";
        var fullPath = Path.Combine(folder, fileName);

        await using var stream = System.IO.File.Create(fullPath);
        await file.CopyToAsync(stream);

        return $"/uploads/athletes/{fileName}";
    }
}
