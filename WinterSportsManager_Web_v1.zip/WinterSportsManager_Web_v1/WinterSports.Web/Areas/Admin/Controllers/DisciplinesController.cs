using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;
using WinterSports.Web.Models;

namespace WinterSports.Web.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize]
public class DisciplinesController : Controller
{
    private readonly AppDbContext _db;

    public DisciplinesController(AppDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        return View(await _db.Disciplines.Include(x => x.Athletes).OrderBy(x => x.Name).ToListAsync());
    }

    [HttpGet]
    public IActionResult Create()
    {
        return View("CreateEdit", new Discipline());
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Discipline discipline)
    {
        if (!ModelState.IsValid)
        {
            return View("CreateEdit", discipline);
        }

        _db.Disciplines.Add(discipline);
        await _db.SaveChangesAsync();

        TempData["Toast"] = "Dodano dyscyplinę.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var discipline = await _db.Disciplines.FindAsync(id);
        return discipline == null ? NotFound() : View("CreateEdit", discipline);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(Discipline discipline)
    {
        if (!ModelState.IsValid)
        {
            return View("CreateEdit", discipline);
        }

        _db.Disciplines.Update(discipline);
        await _db.SaveChangesAsync();

        TempData["Toast"] = "Zapisano dyscyplinę.";
        return RedirectToAction(nameof(Index));
    }
}
