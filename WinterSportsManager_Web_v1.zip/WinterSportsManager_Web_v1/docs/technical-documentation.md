# Dokumentacja techniczna

## Cel

Aplikacja webowa do zarządzania zawodnikami sportów zimowych. Projekt przenosi temat starej aplikacji WPF do środowiska ASP.NET Core MVC.

## Architektura

Aplikacja ma prostą architekturę MVC:

- `Models` - modele danych,
- `Data` - `AppDbContext` i seed,
- `Controllers` - publiczne kontrolery,
- `Areas/Admin` - panel administracyjny,
- `Services` - logowanie i eksport CSV,
- `Views` - Razor Views,
- `wwwroot` - CSS, JS, uploady.

## Modele

### Athlete

Reprezentuje zawodnika. Odpowiada starej encji `Zawodnik`.

Najważniejsze pola:

- `FirstName`
- `LastName`
- `Age`
- `Country`
- `ClubName`
- `Points`
- `Status`
- `PhotoPath`
- `DisciplineId`

### Discipline

Odpowiada staremu enumowi i klasom specjalizacji typu `NarciarzAlpejski`, `Snowboardzista`, ale w webapp jest modelem słownikowym w bazie.

### CompetitionEvent

Reprezentuje zawody.

### Result

Odpowiada starej klasie `WynikZawodow`.

### PageContent

Pozwala edytować treści strony z panelu admina.

### AdminUser

Prosty użytkownik administracyjny do logowania cookie.

## Relacje

- jedna dyscyplina ma wielu zawodników,
- jedna dyscyplina ma wiele zawodów,
- jeden zawodnik ma wiele wyników,
- jedne zawody mają wiele wyników.

## Autentykacja

Zastosowano Cookie Authentication. Panel admina jest zabezpieczony atrybutem `[Authorize]`.

## Wykresy

Wykresy są oparte o Chart.js:

- zawodnicy według dyscypliny,
- top zawodnicy według punktów.

Dane są przekazywane z kontrolera do Razor View i serializowane do JSON.

## Decyzje projektowe

1. SQLite zamiast LocalDB, bo łatwiej uruchomić projekt w zespole.
2. Cookie auth zamiast pełnego Identity, bo projekt ma być prosty do obrony.
3. `EnsureCreated()` w pierwszej wersji, aby aplikacja startowała bez ręcznego tworzenia migracji.
4. Zachowanie tematu starego WPF: zawodnicy, dyscypliny, wyniki, ranking, klub.

## Rozszerzenia

- pełne ASP.NET Core Identity,
- role Admin/Editor,
- migracje EF zamiast `EnsureCreated()`,
- testy integracyjne,
- pełny CRUD zawodów,
- sortowanie AJAX,
- import CSV.
