using System.ComponentModel.DataAnnotations;

namespace WinterSports.Web.Models;

public class AdminUser
{
    public int Id { get; set; }

    [Required]
    [EmailAddress]
    public string Email { get; set; } = string.Empty;

    [Required]
    public string PasswordHash { get; set; } = string.Empty;
}
