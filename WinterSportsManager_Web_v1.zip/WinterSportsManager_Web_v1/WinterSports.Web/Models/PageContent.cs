using System.ComponentModel.DataAnnotations;

namespace WinterSports.Web.Models;

public class PageContent
{
    public int Id { get; set; }

    [Required]
    [StringLength(80)]
    public string Key { get; set; } = string.Empty;

    [Required]
    [StringLength(160)]
    [Display(Name = "Tytuł")]
    public string Title { get; set; } = string.Empty;

    [Required]
    [StringLength(3000)]
    [Display(Name = "Treść")]
    public string Body { get; set; } = string.Empty;
}
