# Winter Sports Manager

Webowa aplikacja ASP.NET Core MVC do zarządzania zawodnikami sportów zimowych. Projekt jest kontynuacją wcześniejszej aplikacji WPF „System zarządzania zawodnikami sportów zimowych”.

## Funkcje

- publiczna strona główna,
- lista zawodników,
- karta zawodnika,
- lista dyscyplin,
- lista wyników,
- dashboard statystyk z Chart.js,
- panel administracyjny,
- logowanie admina,
- CRUD zawodników,
- CRUD dyscyplin,
- CRUD wyników,
- edycja podstawowych treści strony,
- upload zdjęcia zawodnika,
- eksport zawodników do CSV,
- responsywny interfejs,
- tryb jasny/ciemny,
- animacje wejścia i hover effects.

## Technologie

- ASP.NET Core MVC 8.0
- Entity Framework Core 8
- SQLite
- Cookie Authentication
- Razor Views
- CSS Grid
- Flexbox
- Media Queries
- Vanilla JavaScript
- Chart.js przez CDN

## Uruchomienie lokalne

Wymagania:

- .NET SDK 8.0
- Visual Studio 2022 albo Rider / VS Code
- przeglądarka

Kroki:

```bash
cd WinterSports.Web
dotnet restore
dotnet run
```

Aplikacja przy pierwszym starcie utworzy lokalną bazę SQLite przez `EnsureCreated()` i doda dane testowe.

Adres będzie widoczny w konsoli, np.:

```text
https://localhost:5001
```

## Konto administratora

Domyślne dane:

```text
login: admin@example.com
hasło: Admin123!
```

Dane można zmienić w `appsettings.json`.

## Struktura katalogów

```text
WinterSports.Web/
├── Areas/Admin
├── Controllers
├── Data
├── Models
├── Services
├── Views
├── wwwroot/css
├── wwwroot/js
├── wwwroot/uploads
├── Program.cs
└── appsettings.json
```

## Praca zespołowa

Proponowany model branchy:

- `main` - stabilna wersja
- `dev` - integracja prac
- `feature/backend`
- `feature/frontend`
- `feature/admin`
- `feature/charts-docs`

Przed commitem nie wrzucać:

- `.vs/`
- `bin/`
- `obj/`
- lokalnej bazy `.db`
- uploadów z `wwwroot/uploads/`

## Ważna decyzja projektowa

W pierwszej wersji użyto prostego logowania cookie zamiast pełnego ASP.NET Core Identity. Jest to świadome uproszczenie: projekt nadal ma logowanie, autoryzację i zabezpieczony panel admina, ale pozostaje łatwy do wyjaśnienia na zajęciach. Jeśli prowadzący wymaga pełnego Identity, można podmienić moduł logowania w kolejnym commicie.
