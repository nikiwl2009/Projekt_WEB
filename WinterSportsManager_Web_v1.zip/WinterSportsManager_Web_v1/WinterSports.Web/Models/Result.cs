using System.ComponentModel.DataAnnotations;

namespace WinterSports.Web.Models;

public class Result
{
    public int Id { get; set; }

    [Required]
    [Display(Name = "Zawodnik")]
    public int AthleteId { get; set; }

    public Athlete? Athlete { get; set; }

    [Required]
    [Display(Name = "Zawody")]
    public int CompetitionEventId { get; set; }

    public CompetitionEvent? CompetitionEvent { get; set; }

    [Range(1, 300, ErrorMessage = "Miejsce musi być w zakresie 1–300.")]
    [Display(Name = "Miejsce")]
    public int Place { get; set; }

    [Range(0, 100000)]
    [Display(Name = "Punkty")]
    public int Points { get; set; }

    [DataType(DataType.Date)]
    [Display(Name = "Data wyniku")]
    public DateTime Date { get; set; } = DateTime.Today;

    [Display(Name = "Notatka")]
    [StringLength(500)]
    public string? Note { get; set; }
}
