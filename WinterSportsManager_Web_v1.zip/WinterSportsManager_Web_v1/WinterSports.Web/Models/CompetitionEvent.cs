using System.ComponentModel.DataAnnotations;

namespace WinterSports.Web.Models;

public class CompetitionEvent
{
    public int Id { get; set; }

    [Required]
    [StringLength(120)]
    [Display(Name = "Nazwa zawodów")]
    public string Name { get; set; } = string.Empty;

    [Display(Name = "Lokalizacja")]
    [StringLength(100)]
    public string Location { get; set; } = string.Empty;

    [Display(Name = "Data")]
    public DateTime Date { get; set; } = DateTime.Today;

    [Range(1, 10)]
    [Display(Name = "Trudność")]
    public int Difficulty { get; set; } = 5;

    [Range(0, 1000)]
    [Display(Name = "Punkty bazowe")]
    public int BasePoints { get; set; } = 100;

    [Required]
    [Display(Name = "Dyscyplina")]
    public int DisciplineId { get; set; }

    public Discipline? Discipline { get; set; }
    public List<Result> Results { get; set; } = new();
}
