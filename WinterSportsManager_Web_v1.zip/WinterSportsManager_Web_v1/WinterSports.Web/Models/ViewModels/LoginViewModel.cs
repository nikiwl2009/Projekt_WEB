using System.ComponentModel.DataAnnotations;

namespace WinterSports.Web.Models.ViewModels;

public class LoginViewModel
{
    [Required(ErrorMessage = "Podaj e-mail.")]
    [EmailAddress]
    [Display(Name = "E-mail")]
    public string Email { get; set; } = string.Empty;

    [Required(ErrorMessage = "Podaj hasło.")]
    [DataType(DataType.Password)]
    [Display(Name = "Hasło")]
    public string Password { get; set; } = string.Empty;

    [Display(Name = "Zapamiętaj mnie")]
    public bool RememberMe { get; set; }
}
