using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;
using WinterSports.Web.Services;

namespace WinterSports.Web.Controllers;

public class AthletesController : Controller
{
    private readonly AppDbContext _db;
    private readonly FileExportService _export;

    public AthletesController(AppDbContext db, FileExportService export)
    {
        _db = db;
        _export = export;
    }

    public async Task<IActionResult> Index(string? search, int? disciplineId, string sort = "points")
    {
        var query = _db.Athletes.Include(x => x.Discipline).AsQueryable();

        if (!string.IsNullOrWhiteSpace(search))
        {
            query = query.Where(x =>
                x.FirstName.Contains(search) ||
                x.LastName.Contains(search) ||
                (x.ClubName != null && x.ClubName.Contains(search)));
        }

        if (disciplineId.HasValue)
        {
            query = query.Where(x => x.DisciplineId == disciplineId.Value);
        }

        query = sort switch
        {
            "name" => query.OrderBy(x => x.LastName).ThenBy(x => x.FirstName),
            "age" => query.OrderBy(x => x.Age),
            _ => query.OrderByDescending(x => x.Points)
        };

        ViewBag.Disciplines = await _db.Disciplines.OrderBy(x => x.Name).ToListAsync();
        ViewBag.Search = search;
        ViewBag.DisciplineId = disciplineId;
        ViewBag.Sort = sort;

        return View(await query.ToListAsync());
    }

    public async Task<IActionResult> Details(int id)
    {
        var athlete = await _db.Athletes
            .Include(x => x.Discipline)
            .Include(x => x.Results)
            .ThenInclude(x => x.CompetitionEvent)
            .FirstOrDefaultAsync(x => x.Id == id);

        if (athlete == null)
        {
            return NotFound();
        }

        return View(athlete);
    }

    public async Task<IActionResult> ExportCsv()
    {
        var athletes = await _db.Athletes.Include(x => x.Discipline).OrderBy(x => x.LastName).ToListAsync();
        return File(_export.AthletesToCsv(athletes), "text/csv", "zawodnicy.csv");
    }
}
