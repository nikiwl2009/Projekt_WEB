using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;
using WinterSports.Web.Models;

namespace WinterSports.Web.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize]
public class ContentController : Controller
{
    private readonly AppDbContext _db;

    public ContentController(AppDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        return View(await _db.PageContents.OrderBy(x => x.Key).ToListAsync());
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var content = await _db.PageContents.FindAsync(id);
        return content == null ? NotFound() : View(content);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(PageContent content)
    {
        if (!ModelState.IsValid)
        {
            return View(content);
        }

        _db.PageContents.Update(content);
        await _db.SaveChangesAsync();

        TempData["Toast"] = "Zapisano treść.";
        return RedirectToAction(nameof(Index));
    }
}
