namespace WinterSports.Web.Models;

public enum AthleteStatus
{
    Aktywny = 1,
    Kontuzjowany = 2,
    Emerytowany = 3
}
