# Instrukcja użytkownika

## Wejście na stronę

Otwórz aplikację w przeglądarce pod adresem podanym przez Visual Studio albo `dotnet run`.

[SCREEN: strona główna]

## Przeglądanie zawodników

Kliknij w menu `Zawodnicy`.

Możesz:

- wyszukać zawodnika po imieniu, nazwisku lub klubie,
- filtrować po dyscyplinie,
- sortować po punktach, nazwisku albo wieku,
- wejść w kartę zawodnika.

[SCREEN: lista zawodników]

## Karta zawodnika

Na karcie zawodnika widać:

- imię i nazwisko,
- dyscyplinę,
- wiek,
- klub,
- punkty,
- status,
- wyniki.

[SCREEN: karta zawodnika]

## Logowanie do panelu admina

Kliknij `Logowanie`.

Dane domyślne:

```text
login: admin@example.com
hasło: Admin123!
```

Po zalogowaniu kliknij `Panel admina`.

[SCREEN: panel admina]

## Dodawanie zawodnika

1. Wejdź w `Panel admina`.
2. Kliknij `Zarządzaj zawodnikami`.
3. Kliknij `Dodaj zawodnika`.
4. Uzupełnij formularz.
5. Opcjonalnie dodaj zdjęcie.
6. Kliknij `Zapisz`.

[SCREEN: formularz dodawania zawodnika]

## Edycja zawodnika

1. Wejdź w listę zawodników w panelu admina.
2. Kliknij `Edytuj`.
3. Popraw dane.
4. Kliknij `Zapisz`.

## Usuwanie zawodnika

1. Wejdź w listę zawodników.
2. Kliknij `Usuń`.
3. Potwierdź usunięcie.

## Dodawanie wyniku

1. Wejdź w panel admina.
2. Kliknij `Zarządzaj wynikami`.
3. Kliknij `Dodaj wynik`.
4. Wybierz zawodnika i zawody.
5. Podaj miejsce, punkty i datę.
6. Zapisz.

## Edycja treści strony

1. Wejdź w `Panel admina`.
2. Kliknij `Edytuj treści strony`.
3. Wybierz treść.
4. Zmień tytuł lub opis.
5. Zapisz.

## Wykresy

Na stronie głównej i w panelu admina widać wykresy:

- liczba zawodników według dyscypliny,
- top zawodnicy według punktów.

[SCREEN: wykresy]
