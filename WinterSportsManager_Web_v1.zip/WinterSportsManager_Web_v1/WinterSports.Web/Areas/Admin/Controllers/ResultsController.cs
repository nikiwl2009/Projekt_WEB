using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;
using WinterSports.Web.Models;

namespace WinterSports.Web.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize]
public class ResultsController : Controller
{
    private readonly AppDbContext _db;

    public ResultsController(AppDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        var results = await _db.Results
            .Include(x => x.Athlete)
            .Include(x => x.CompetitionEvent)
            .OrderByDescending(x => x.Date)
            .ToListAsync();

        return View(results);
    }

    [HttpGet]
    public async Task<IActionResult> Create()
    {
        await FillLists();
        return View("CreateEdit", new Result { Date = DateTime.Today });
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Create(Result result)
    {
        if (!ModelState.IsValid)
        {
            await FillLists();
            return View("CreateEdit", result);
        }

        _db.Results.Add(result);
        await _db.SaveChangesAsync();
        await RecalculateAthletePoints(result.AthleteId);

        TempData["Toast"] = "Dodano wynik.";
        return RedirectToAction(nameof(Index));
    }

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var result = await _db.Results.FindAsync(id);

        if (result == null)
        {
            return NotFound();
        }

        await FillLists();
        return View("CreateEdit", result);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Edit(Result result)
    {
        if (!ModelState.IsValid)
        {
            await FillLists();
            return View("CreateEdit", result);
        }

        _db.Results.Update(result);
        await _db.SaveChangesAsync();
        await RecalculateAthletePoints(result.AthleteId);

        TempData["Toast"] = "Zapisano wynik.";
        return RedirectToAction(nameof(Index));
    }

    private async Task FillLists()
    {
        ViewBag.Athletes = new SelectList(
            await _db.Athletes.OrderBy(x => x.LastName).Select(x => new { x.Id, FullName = x.FirstName + " " + x.LastName }).ToListAsync(),
            "Id",
            "FullName");

        ViewBag.Events = new SelectList(
            await _db.CompetitionEvents.OrderByDescending(x => x.Date).ToListAsync(),
            "Id",
            "Name");
    }

    private async Task RecalculateAthletePoints(int athleteId)
    {
        var athlete = await _db.Athletes.Include(x => x.Results).FirstOrDefaultAsync(x => x.Id == athleteId);

        if (athlete == null)
        {
            return;
        }

        athlete.Points = athlete.Results.Sum(x => x.Points);
        await _db.SaveChangesAsync();
    }
}
