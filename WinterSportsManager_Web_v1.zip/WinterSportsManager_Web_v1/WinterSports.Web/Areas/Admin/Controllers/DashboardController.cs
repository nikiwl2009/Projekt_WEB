using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WinterSports.Web.Data;
using WinterSports.Web.Models.ViewModels;

namespace WinterSports.Web.Areas.Admin.Controllers;

[Area("Admin")]
[Authorize]
public class DashboardController : Controller
{
    private readonly AppDbContext _db;

    public DashboardController(AppDbContext db)
    {
        _db = db;
    }

    public async Task<IActionResult> Index()
    {
        var vm = new DashboardViewModel
        {
            AthletesCount = await _db.Athletes.CountAsync(),
            DisciplinesCount = await _db.Disciplines.CountAsync(),
            EventsCount = await _db.CompetitionEvents.CountAsync(),
            ResultsCount = await _db.Results.CountAsync(),
            AthletesByDiscipline = await _db.Disciplines
                .Select(x => new KeyValuePair<string, int>(x.Name, x.Athletes.Count))
                .ToListAsync(),
            TopAthletes = await _db.Athletes
                .OrderByDescending(x => x.Points)
                .Take(6)
                .Select(x => new KeyValuePair<string, int>(x.FirstName + " " + x.LastName, x.Points))
                .ToListAsync(),
            LatestResults = await _db.Results
                .Include(x => x.Athlete)
                .Include(x => x.CompetitionEvent)
                .OrderByDescending(x => x.Date)
                .Take(8)
                .ToListAsync()
        };

        return View(vm);
    }
}
