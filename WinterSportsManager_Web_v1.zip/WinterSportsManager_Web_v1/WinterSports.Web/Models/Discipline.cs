using System.ComponentModel.DataAnnotations;

namespace WinterSports.Web.Models;

public class Discipline
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Podaj nazwę dyscypliny.")]
    [StringLength(80, MinimumLength = 2)]
    [Display(Name = "Nazwa")]
    public string Name { get; set; } = string.Empty;

    [Display(Name = "Opis")]
    [StringLength(700)]
    public string? Description { get; set; }

    [Display(Name = "Kolor akcentu")]
    [StringLength(20)]
    public string AccentColor { get; set; } = "#38bdf8";

    public List<Athlete> Athletes { get; set; } = new();
    public List<CompetitionEvent> Events { get; set; } = new();
}
